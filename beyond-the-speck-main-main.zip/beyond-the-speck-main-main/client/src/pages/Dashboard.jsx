import React from 'react';

const Dashboard = () => {
    return (
        <div className="container mx-auto px-4 py-8">
        </div>
    )};


export default Dashboard